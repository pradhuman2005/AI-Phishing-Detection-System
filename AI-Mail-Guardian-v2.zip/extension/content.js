/**
 * AI Mail Guardian - Gmail Content Script (Manifest V3)
 * Injects colored threat badges into Gmail inbox and open-email views.
 * Displays a plain-language security drawer on click.
 * Supports On-Demand Scanning with scan=1 when an email is not yet analyzed.
 * Strictly uses textContent (never innerHTML) for defense against untrusted email content.
 */

(() => {
  if (window.__aiMailGuardianLoaded) return;
  window.__aiMailGuardianLoaded = true;

  const RETRY_INTERVAL_MS = 60000; // 60s retry for pending items
  const MAX_RETRIES = 5;
  const MAX_CONCURRENT_REQUESTS = 4;

  const reportCache = new Map(); // threadId -> report response
  const retryCountMap = new Map(); // threadId -> number of retries
  const pendingRequests = new Set(); // threadId currently in-flight
  const badgeMap = new Map(); // threadId -> Set of badge DOM elements

  let activePanel = null;
  let activeOverlay = null;

  // -------------------------------------------------------------------------
  // Concurrency-limited Request Queue
  // -------------------------------------------------------------------------
  class RequestQueue {
    constructor(limit) {
      this.limit = limit;
      this.running = 0;
      this.queue = [];
    }

    push(taskFn) {
      return new Promise((resolve, reject) => {
        this.queue.push({ taskFn, resolve, reject });
        this.dequeue();
      });
    }

    dequeue() {
      if (this.running >= this.limit || this.queue.length === 0) return;
      const { taskFn, resolve, reject } = this.queue.shift();
      this.running++;

      taskFn()
        .then(resolve)
        .catch(reject)
        .finally(() => {
          this.running--;
          this.dequeue();
        });
    }
  }

  const queue = new RequestQueue(MAX_CONCURRENT_REQUESTS);

  // -------------------------------------------------------------------------
  // Safe DOM Helper (strictly no innerHTML)
  // -------------------------------------------------------------------------
  function createEl(tag, className, textContent) {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (textContent !== undefined && textContent !== null) {
      el.textContent = String(textContent);
    }
    return el;
  }

  // -------------------------------------------------------------------------
  // Thread ID Extraction & Decimal -> Hex BigInt Converter
  // -------------------------------------------------------------------------
  function parseThreadId(rawId) {
    if (!rawId || typeof rawId !== "string") return null;
    const trimmed = rawId.trim();

    // 1. Direct hex string (standard 16-character hex thread ID from Gmail)
    if (/^[0-9a-f]{16}$/i.test(trimmed)) {
      return trimmed.toLowerCase();
    }

    // 2. Gmail decimal thread format (e.g. "#thread-f:1812345678901234567" or "thread-f:1812345678901234567")
    const match = trimmed.match(/\d{15,20}/);
    if (match) {
      try {
        const bigIntVal = BigInt(match[0]);
        return bigIntVal.toString(16).toLowerCase();
      } catch {
        return null;
      }
    }

    return trimmed;
  }

  function getRowThreadId(row) {
    const legacyId =
      row.getAttribute("data-legacy-thread-id") ||
      row.querySelector("[data-legacy-thread-id]")?.getAttribute("data-legacy-thread-id");
    if (legacyId) {
      const parsed = parseThreadId(legacyId);
      if (parsed) return parsed;
    }

    const threadId =
      row.getAttribute("data-thread-id") ||
      row.querySelector("[data-thread-id]")?.getAttribute("data-thread-id");
    if (threadId) {
      const parsed = parseThreadId(threadId);
      if (parsed) return parsed;
    }

    const legacyMsgId =
      row.getAttribute("data-legacy-message-id") ||
      row.querySelector("[data-legacy-message-id]")?.getAttribute("data-legacy-message-id");
    if (legacyMsgId) {
      const parsed = parseThreadId(legacyMsgId);
      if (parsed) return parsed;
    }

    return null;
  }

  function getOpenEmailThreadId() {
    const container =
      document.querySelector("[data-legacy-thread-id]") ||
      document.querySelector("[data-thread-id]");
    if (container) {
      const parsed =
        parseThreadId(container.getAttribute("data-legacy-thread-id")) ||
        parseThreadId(container.getAttribute("data-thread-id"));
      if (parsed) return parsed;
    }

    const hash = window.location.hash;
    if (hash) {
      const parts = hash.split("/");
      const lastPart = parts[parts.length - 1];
      if (lastPart && /^[0-9a-f]{16}$/i.test(lastPart)) {
        return lastPart.toLowerCase();
      }
    }

    return null;
  }

  // -------------------------------------------------------------------------
  // Risk Level & Verdict Formatting
  // -------------------------------------------------------------------------
  function getScoreInfo(score, riskLevel) {
    if (typeof score !== "number" || isNaN(score)) {
      return {
        cls: "none",
        label: "Scan Incomplete",
        text: "Scan Incomplete",
        dot: "⚪",
        headClass: "head-neutral",
        desc: "Security scan is in progress or could not be completed."
      };
    }

    if (score <= 25) {
      return {
        cls: "low",
        label: "Low Risk",
        text: `${score}/100 · Low risk`,
        dot: "🟢",
        headClass: "head-low",
        desc: "No significant phishing signals detected. Email appears safe."
      };
    }
    if (score <= 50) {
      return {
        cls: "mod",
        label: "Moderate Risk",
        text: `${score}/100 · Moderate risk`,
        dot: "🟡",
        headClass: "head-mod",
        desc: "Some suspicious patterns detected. Exercise caution before clicking links or replying."
      };
    }
    if (score <= 75) {
      return {
        cls: "high",
        label: "High Risk",
        text: `${score}/100 · High risk`,
        dot: "🟠",
        headClass: "head-high",
        desc: "Multiple threat indicators found. High probability of deceptive intent."
      };
    }
    return {
      cls: "crit",
      label: "Critical Risk",
      text: `${score}/100 · Critical risk`,
      dot: "🔴",
      headClass: "head-crit",
      desc: "Dangerous phishing or malware indicators detected! Do NOT click links or enter passwords."
    };
  }

  // -------------------------------------------------------------------------
  // Fetch Report (Read-only vs On-Demand Scan)
  // -------------------------------------------------------------------------
  function fetchReportSafe(threadId, requestScan = false) {
    return new Promise((resolve) => {
      if (!chrome.runtime?.id) {
        console.warn("[AI Mail Guardian] Extension context invalidated. Please refresh Gmail.");
        resolve({ ok: false, error: "CONTEXT_INVALIDATED" });
        return;
      }

      try {
        chrome.runtime.sendMessage(
          {
            type: "GET_SECURITY_REPORT",
            email_id: threadId,
            scan: requestScan ? 1 : 0
          },
          (response) => {
            if (chrome.runtime.lastError) {
              resolve({
                ok: false,
                error: "WORKER_ERROR",
                message: chrome.runtime.lastError.message
              });
              return;
            }
            resolve(response || { ok: false, error: "NO_RESPONSE" });
          }
        );
      } catch (e) {
        resolve({ ok: false, error: "EXCEPTION", message: String(e) });
      }
    });
  }

  // -------------------------------------------------------------------------
  // Badge Registration & UI Updates
  // -------------------------------------------------------------------------
  function registerBadge(threadId, badgeElement) {
    if (!badgeMap.has(threadId)) {
      badgeMap.set(threadId, new Set());
    }
    badgeMap.get(threadId).add(badgeElement);
  }

  function updateAllBadges(threadId, res) {
    const badges = badgeMap.get(threadId);
    if (!badges) return;
    badges.forEach((badge) => {
      if (badge && badge.isConnected) {
        renderBadgeState(badge, threadId, res);
      }
    });
  }

  function renderBadgeState(badge, threadId, res) {
    if (res && res.ok) {
      const score = res.risk_score ?? res.report?.risk_score ?? null;
      const level = res.risk_level ?? res.report?.risk_level ?? null;
      const info = getScoreInfo(score, level);

      badge.className = `amg-inbox-badge amg-badge-${info.cls}`;
      badge.textContent = `${info.dot} ${info.text}`;
      badge.setAttribute("title", `AI Mail Guardian: ${info.desc} Click to view full report.`);
    } else {
      // Unscanned -> Show grey "Scan now" badge
      badge.className = "amg-inbox-badge amg-badge-scannow";
      badge.textContent = "🛡️ Scan now";
      badge.setAttribute("title", "AI Mail Guardian: Not scanned yet. Click to trigger instant AI analysis.");
    }
  }

  async function loadInitialReport(threadId, badgeElement) {
    if (!threadId) return;
    registerBadge(threadId, badgeElement);

    if (reportCache.has(threadId)) {
      renderBadgeState(badgeElement, threadId, reportCache.get(threadId));
      return;
    }

    if (pendingRequests.has(threadId)) return;
    pendingRequests.add(threadId);

    // Initial check without scan=1 (read-only, fast)
    const res = await queue.push(() => fetchReportSafe(threadId, false));
    pendingRequests.delete(threadId);

    if (res && res.ok) {
      reportCache.set(threadId, res);
      updateAllBadges(threadId, res);
    } else {
      renderBadgeState(badgeElement, threadId, { ok: false });
    }
  }

  // -------------------------------------------------------------------------
  // On-Demand Scan Trigger (when user clicks "Scan now" or button)
  // -------------------------------------------------------------------------
  async function triggerOnDemandScan(threadId) {
    // 1. Open panel in loading state immediately
    openSidePanel(threadId, true);

    // Update all badges for this thread to scanning state
    const badges = badgeMap.get(threadId);
    if (badges) {
      badges.forEach((b) => {
        if (b && b.isConnected) {
          b.className = "amg-inbox-badge amg-badge-scanning";
          b.textContent = "⏳ Scanning...";
        }
      });
    }

    // 2. Call webhook WITH scan=1
    const res = await fetchReportSafe(threadId, true);

    if (res && res.ok) {
      reportCache.set(threadId, res);
      updateAllBadges(threadId, res);
    }

    // 3. Render full panel result
    if (activePanel && activePanel.isConnected) {
      renderPanelContent(activePanel, res, threadId);
    }
  }

  // -------------------------------------------------------------------------
  // Inbox View Processor
  // -------------------------------------------------------------------------
  function processInboxRow(row) {
    if (row.querySelector(".amg-inbox-badge")) return;

    const threadId = getRowThreadId(row);
    if (!threadId) return;

    const badge = createEl("span", "amg-inbox-badge amg-badge-none", "🛡️ ...");
    badge.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();

      const cached = reportCache.get(threadId);
      if (cached && cached.ok) {
        openSidePanel(threadId, false);
      } else {
        // Not scanned yet -> trigger on-demand scan!
        triggerOnDemandScan(threadId);
      }
    });

    const target =
      row.querySelector(".y6") ||
      row.querySelector(".bog") ||
      row.querySelector("span[data-thread-id]") ||
      row.querySelector("td:nth-child(5)") ||
      row.querySelector("td:last-child");

    if (target) {
      if (target.classList.contains("y6")) {
        target.prepend(badge);
      } else {
        target.appendChild(badge);
      }
      loadInitialReport(threadId, badge);
    }
  }

  // -------------------------------------------------------------------------
  // Open Email View Processor
  // -------------------------------------------------------------------------
  function processOpenEmail() {
    const subjectEl = document.querySelector("h2.hP");
    if (!subjectEl) return;

    const threadId = getOpenEmailThreadId();
    if (!threadId) return;

    if (!subjectEl.parentElement.querySelector(".amg-view-report-btn")) {
      const isScanned = reportCache.has(threadId) && reportCache.get(threadId).ok;

      const btn = createEl(
        "button",
        "amg-view-report-btn",
        isScanned ? "🛡️ View Security Report" : "🛡️ Scan Email Now"
      );
      btn.type = "button";
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const cached = reportCache.get(threadId);
        if (cached && cached.ok) {
          openSidePanel(threadId, false);
        } else {
          triggerOnDemandScan(threadId);
        }
      });

      const badge = createEl("span", "amg-inbox-badge amg-badge-none", "🛡️ ...");
      badge.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const cached = reportCache.get(threadId);
        if (cached && cached.ok) {
          openSidePanel(threadId, false);
        } else {
          triggerOnDemandScan(threadId);
        }
      });

      subjectEl.parentElement.appendChild(badge);
      subjectEl.parentElement.appendChild(btn);

      loadInitialReport(threadId, badge);
    }
  }

  // -------------------------------------------------------------------------
  // Full Security Report Side Panel (strictly textContent, 0 innerHTML)
  // -------------------------------------------------------------------------
  function closeSidePanel() {
    if (activePanel) {
      activePanel.remove();
      activePanel = null;
    }
    if (activeOverlay) {
      activeOverlay.remove();
      activeOverlay = null;
    }
    document.removeEventListener("keydown", handleEscKey);
  }

  function handleEscKey(e) {
    if (e.key === "Escape") closeSidePanel();
  }

  function appendRow(parent, labelText, valueText, valueClass) {
    const r = createEl("div", "amg-info-row");
    r.appendChild(createEl("span", "amg-label", labelText));
    r.appendChild(createEl("span", `amg-value ${valueClass || ""}`, valueText));
    parent.appendChild(r);
  }

  async function openSidePanel(threadId, isLoadingMode = false) {
    closeSidePanel();

    activeOverlay = createEl("div", "amg-panel-overlay visible");
    activeOverlay.addEventListener("click", closeSidePanel);
    document.body.appendChild(activeOverlay);

    activePanel = createEl("aside", "amg-side-panel");
    document.body.appendChild(activePanel);
    document.addEventListener("keydown", handleEscKey);

    if (isLoadingMode) {
      renderLoadingPanel(activePanel, threadId, "Scanning email with AI & VirusTotal...");
      return;
    }

    let res = reportCache.get(threadId);
    if (!res || !res.ok) {
      renderLoadingPanel(activePanel, threadId, "Loading security report...");
      res = await fetchReportSafe(threadId, false);
      if (res && res.ok) {
        reportCache.set(threadId, res);
        updateAllBadges(threadId, res);
      }
    }

    if (!activePanel || !activePanel.isConnected) return;
    renderPanelContent(activePanel, res, threadId);
  }

  function renderLoadingPanel(panel, threadId, message) {
    panel.textContent = "";

    const head = createEl("div", "amg-panel-head head-neutral");
    const closeBtn = createEl("button", "amg-panel-close", "×");
    closeBtn.addEventListener("click", closeSidePanel);
    head.appendChild(closeBtn);
    head.appendChild(createEl("h2", "amg-panel-title", "AI Mail Guardian"));
    head.appendChild(createEl("p", "amg-panel-subtitle", "Security Analysis in Progress"));
    panel.appendChild(head);

    const body = createEl("div", "amg-panel-body");
    const card = createEl("div", "amg-info-card");
    const p = createEl("p", "amg-loading-text", message || "Analyzing email threat indicators...");
    card.appendChild(p);

    const spinner = createEl("div", "amg-spinner");
    card.appendChild(spinner);

    body.appendChild(card);
    panel.appendChild(body);
  }

  function renderPanelContent(panel, res, requestedId) {
    panel.textContent = "";

    if (!res || !res.ok) {
      const head = createEl("div", "amg-panel-head head-neutral");
      const closeBtn = createEl("button", "amg-panel-close", "×");
      closeBtn.addEventListener("click", closeSidePanel);
      head.appendChild(closeBtn);
      head.appendChild(createEl("h2", "amg-panel-title", "AI Mail Guardian"));
      head.appendChild(createEl("p", "amg-panel-subtitle", "Email Not Scanned Yet"));
      panel.appendChild(head);

      const body = createEl("div", "amg-panel-body");
      const card = createEl("div", "amg-info-card");
      card.appendChild(createEl("h4", "", "Scan Status: Not Analyzed"));
      card.appendChild(
        createEl(
          "p",
          "",
          res?.message ||
            "This email has not been processed yet. Click the button below to perform an instant on-demand AI scan."
        )
      );

      const scanBtn = createEl("button", "amg-action-btn", "⚡ Scan This Email Now");
      scanBtn.addEventListener("click", () => {
        triggerOnDemandScan(requestedId);
      });
      card.appendChild(scanBtn);

      body.appendChild(card);
      panel.appendChild(body);
      return;
    }

    const report = res.report || {};
    const emailMeta = report.email || {};
    const score = res.risk_score ?? report.risk_score ?? null;
    const level = res.risk_level ?? report.risk_level ?? null;
    const info = getScoreInfo(score, level);

    // 1. Header
    const head = createEl("div", `amg-panel-head ${info.headClass}`);
    const closeBtn = createEl("button", "amg-panel-close", "×");
    closeBtn.addEventListener("click", closeSidePanel);
    head.appendChild(closeBtn);

    head.appendChild(createEl("h2", "amg-panel-title", `Security Verdict: ${info.label}`));
    head.appendChild(
      createEl(
        "p",
        "amg-panel-subtitle",
        typeof score === "number" ? `Risk Score: ${score} / 100` : "Score: Incomplete"
      )
    );

    if (typeof score === "number") {
      const meter = createEl("div", "amg-score-meter");
      const fill = createEl("div", "amg-score-fill");
      fill.style.width = `${Math.max(0, Math.min(100, score))}%`;
      meter.appendChild(fill);
      head.appendChild(meter);
    }
    panel.appendChild(head);

    // 2. Body
    const body = createEl("div", "amg-panel-body");

    // Email Info Card
    body.appendChild(createEl("div", "amg-section-title", "Email Overview"));
    const emailCard = createEl("div", "amg-info-card");
    appendRow(emailCard, "Sender", emailMeta.sender || "Unknown sender");
    appendRow(emailCard, "Subject", emailMeta.subject || res.subject || "(No subject)");
    appendRow(emailCard, "Thread ID", emailMeta.thread_id || requestedId);
    if (emailMeta.received_at) {
      appendRow(emailCard, "Received", new Date(emailMeta.received_at).toLocaleString());
    }
    body.appendChild(emailCard);

    // Sender Authentication (SPF / DKIM / DMARC)
    body.appendChild(createEl("div", "amg-section-title", "Sender Verification (SPF / DKIM / DMARC)"));
    const authCard = createEl("div", "amg-info-card");
    const auth = report.email_auth || {};

    ["spf", "dkim", "dmarc"].forEach((k) => {
      const val = String(auth[k] || "unknown").toLowerCase();
      let pillClass = "amg-auth-unknown";
      if (val === "pass") pillClass = "amg-auth-pass";
      else if (val === "fail" || val === "softfail") pillClass = "amg-auth-fail";

      const r = createEl("div", "amg-info-row");
      r.appendChild(createEl("span", "amg-label", `${k.toUpperCase()} Record`));
      r.appendChild(createEl("span", `amg-auth-pill ${pillClass}`, val));
      authCard.appendChild(r);
    });
    body.appendChild(authCard);

    // AI Threat Analysis
    body.appendChild(createEl("div", "amg-section-title", "AI Threat Analysis (Gemini)"));
    const aiCard = createEl("div", "amg-info-card");
    const ai = report.ai_analysis || {};

    if (ai.summary) {
      aiCard.appendChild(createEl("p", "", ai.summary));
    }

    const reasons = Array.isArray(ai.reasons) ? ai.reasons : [];
    if (reasons.length > 0) {
      aiCard.appendChild(createEl("div", "amg-section-title", "Flagged Signals"));
      const ul = createEl("ul", "amg-reasons-list");
      reasons.forEach((r) => ul.appendChild(createEl("li", "", r)));
      aiCard.appendChild(ul);
    }
    body.appendChild(aiCard);

    // URL Security Scans (VirusTotal)
    body.appendChild(createEl("div", "amg-section-title", "Link Intelligence (VirusTotal)"));
    const urlScan = report.url_scan || {};
    const urlResults = Array.isArray(urlScan.results) ? urlScan.results : [];

    if (urlResults.length > 0) {
      urlResults.forEach((u) => {
        const item = createEl("div", "amg-url-item");
        item.appendChild(createEl("div", "amg-url-text", u.original_url || "Unknown link"));

        const stats = u.analysis_stats || {};
        let tagText = "Clean (0 flagged)";
        let tagClass = "tag-clean";

        if (!u.found_in_virustotal) {
          tagText = "Never scanned by VT (not verified safe)";
          tagClass = "tag-unseen";
        } else if ((stats.malicious || 0) > 0) {
          tagText = `Malicious (${stats.malicious} engines flagged)`;
          tagClass = "tag-malicious";
        } else if ((stats.suspicious || 0) > 0) {
          tagText = `Suspicious (${stats.suspicious} engines flagged)`;
          tagClass = "tag-suspicious";
        }

        item.appendChild(createEl("span", `amg-url-tag ${tagClass}`, tagText));
        body.appendChild(item);
      });
    } else {
      const emptyUrlCard = createEl("div", "amg-info-card");
      emptyUrlCard.appendChild(createEl("p", "", urlScan.reason || "No links found in this email."));
      body.appendChild(emptyUrlCard);
    }

    // Attachment Analysis (VirusTotal)
    body.appendChild(createEl("div", "amg-section-title", "Attachment Analysis (VirusTotal)"));
    const attachScan = report.attachment_scan || {};
    const attachCard = createEl("div", "amg-info-card");
    const attachStats = attachScan.stats || {};

    appendRow(attachCard, "Scan Status", attachScan.status || "Skipped");
    if (attachScan.status === "completed") {
      appendRow(
        attachCard,
        "Detections",
        `${attachStats.malicious || 0} malicious / ${attachScan.total_engines || 0} engines`
      );
    } else if (attachScan.reason) {
      appendRow(attachCard, "Details", attachScan.reason);
    }

    if (attachScan.report_url && String(attachScan.report_url).startsWith("https://www.virustotal.com/")) {
      const linkP = createEl("p", "", "");
      const link = createEl("a", "amg-link", "View full VirusTotal analysis report ↗");
      link.href = attachScan.report_url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      linkP.appendChild(link);
      attachCard.appendChild(linkP);
    }
    body.appendChild(attachCard);

    // Recommended Action
    body.appendChild(createEl("div", "amg-section-title", "Recommended Action"));
    const actionCard = createEl("div", "amg-info-card");
    actionCard.appendChild(
      createEl(
        "p",
        "",
        ai.recommended_action || "Carefully review this email before interacting with links or replying."
      )
    );
    body.appendChild(actionCard);

    // Disclaimer
    const disc = createEl(
      "div",
      "amg-disclaimer",
      report.note ||
        "Risk scores are algorithmic estimates. Skipped, pending, or incomplete scans do not establish that an email is safe."
    );
    body.appendChild(disc);

    panel.appendChild(body);
  }

  // -------------------------------------------------------------------------
  // Main Scan Loop & MutationObserver with Debounce
  // -------------------------------------------------------------------------
  function scanGmail() {
    const rows = document.querySelectorAll("tr.zA");
    rows.forEach(processInboxRow);
    processOpenEmail();
  }

  let debounceTimer = null;
  const observer = new MutationObserver(() => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(scanGmail, 250);
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  // Initial trigger
  scanGmail();
})();
