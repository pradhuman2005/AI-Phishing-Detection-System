/**
 * AI Mail Guardian - Background Service Worker (Manifest V3)
 * Fetches threat analysis reports from the local n8n webhook.
 * Performing fetches here bypasses Gmail's page Content Security Policy (CSP) and CORS restrictions.
 */

const WEBHOOK_URL = "http://localhost:5678/webhook/mail-security-report";

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== "object") return false;

  if (msg.type === "GET_SECURITY_REPORT") {
    fetchSecurityReport(msg.email_id, msg.scan)
      .then(sendResponse)
      .catch((err) => {
        sendResponse({
          ok: false,
          error: "INTERNAL_ERROR",
          message: String(err?.message || err)
        });
      });
    return true; // Keep message channel open for async response
  }

  return false;
});

async function fetchSecurityReport(emailId, isScanRequested) {
  if (!emailId) {
    return {
      ok: false,
      error: "MISSING_EMAIL_ID",
      message: "No email ID or thread ID provided."
    };
  }

  const targetUrl = new URL(WEBHOOK_URL);
  targetUrl.searchParams.set("email_id", String(emailId).trim());

  // If scan is explicitly requested (on-demand scan), attach scan=1
  if (isScanRequested) {
    targetUrl.searchParams.set("scan", "1");
  }

  // 60s timeout for on-demand scan, 10s timeout for read-only check
  const timeoutMs = isScanRequested ? 60000 : 10000;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(targetUrl.toString(), {
      method: "GET",
      headers: {
        Accept: "application/json"
      },
      signal: controller.signal
    });

    clearTimeout(timer);

    if (res.status === 404) {
      return {
        ok: false,
        error: "REPORT_NOT_FOUND",
        message: "No report found in database for this email.",
        email_id: emailId
      };
    }

    if (!res.ok) {
      return {
        ok: false,
        error: "SERVER_ERROR",
        message: `n8n server returned HTTP status ${res.status} (${res.statusText})`,
        email_id: emailId
      };
    }

    const text = await res.text();
    if (!text || !text.trim()) {
      return {
        ok: false,
        error: "EMPTY_RESPONSE",
        message: "Webhook returned an empty response.",
        email_id: emailId
      };
    }

    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      return {
        ok: false,
        error: "INVALID_JSON_RESPONSE",
        message: "Webhook response could not be parsed as JSON.",
        email_id: emailId
      };
    }

    const data = Array.isArray(parsed) ? parsed[0] : parsed;

    if (!data) {
      return {
        ok: false,
        error: "REPORT_NOT_FOUND",
        message: "No report object found in response.",
        email_id: emailId
      };
    }

    if (data.ok === false) {
      return data;
    }

    let report = data.report || data;
    if (typeof report.report_json === "string") {
      try {
        report = JSON.parse(report.report_json);
      } catch {}
    }

    return {
      ok: true,
      email_id: data.email_id || report?.email?.email_id || emailId,
      thread_id: data.thread_id || report?.email?.thread_id || emailId,
      subject: data.subject || report?.email?.subject || null,
      risk_score: data.risk_score ?? report?.risk_score ?? null,
      risk_level: data.risk_level ?? report?.risk_level ?? "Needs Review",
      scanned_at: data.scanned_at || report?.report_generated_at || null,
      report: report
    };
  } catch (err) {
    clearTimeout(timer);
    const isAbort = err.name === "AbortError";
    return {
      ok: false,
      error: isAbort ? "TIMEOUT" : "CONNECTION_ERROR",
      message: isAbort
        ? `Request timed out after ${timeoutMs / 1000} seconds.`
        : "Cannot reach n8n server on http://localhost:5678. Ensure Docker container is running.",
      email_id: emailId
    };
  }
}
