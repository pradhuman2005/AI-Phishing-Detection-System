AI Mail Guardian v2 - Quick Setup
1. n8n: Import /n8n/Phishing_Detector_Fixed.json and click Publish (toggle Active).
   Credentials & Data Table auto-link immediately. (To enable VT, paste key in 'VirusTotal Config' node).
2. Chrome: Go to chrome://extensions -> enable Developer mode -> click 'Load unpacked' -> select /extension/ folder.
3. Open Gmail (https://mail.google.com).
-> Colored risk badges appear next to emails; click any badge to open the full security report.
-> For unscanned emails, click the grey 'Scan now' badge for instant on-demand AI analysis.
